<?php
include('connection.php');

function sendWhatsappMessage($phone, $message)
{
    // Your code to send WhatsApp messages goes here
    require_once('ultramsg.class.php'); // if you download ultramsg.class.php

    $token = "ecr85qnhd8x2opxs"; // Ultramsg.com token
    $instance_id = "instance70482"; // Ultramsg.com instance id
    $client = new UltraMsg\WhatsAppApi($token, $instance_id);

    $to = $phone;
    $body = $message;
    $api = $client->sendChatMessage($to, $body);
    print_r($api);
}

date_default_timezone_set('Africa/Cairo');

// while (true) {
$query = "SELECT c.id_client, c.nom_client, c.num_client, t.hours, t.id_trt, t.days, t.start_date, t.end_date, f.text_form, m.fin_txt
FROM client c
JOIN trt t ON c.id_client = t.id_client
JOIN form f ON c.id_user = f.id_user
JOIN fin_form m ON c.id_user= m.id_user
";

$result = mysqli_query($con, $query);

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $id_trt = $row['id_trt'];
        $hours = $row['hours'];
        $days = $row['days'];
        $client_phone = $row['num_client'];
        $client_name = $row['nom_client'];
        $ff = $row['text_form'];
        $fm = $row['fin_txt'];
        //   $times=$row['next'];
        $startDate = strtotime($row['start_date']);
        $endDate = strtotime($row['end_date']);
        $currentDate = time();

        if ($startDate >= $endDate) {
            // echo "Final message should be sent";
            $fm = str_replace("بالعميل", $client_name, $fm);
            echo $fm;

            //  $sql2 = "DELETE FROM `trt` WHERE `trt`.`id_trt` = $id_trt";
            //   $res2 = mysqli_query($con, $sql2);
        } else if ($currentDate < $endDate) {

            $nexttime = $startDate + $hours * 3600;
            if ($currentDate >= ($nexttime - 58) && $currentDate <= ($nexttime + 58)) {
                $next = date("Y-m-d H:i:s", $nexttime);
                $sql1 = "UPDATE `trt` SET `start_date` = '$next' WHERE `trt`.`id_trt` = $id_trt";
                $res1 = mysqli_query($con, $sql1);

                if ($res1) {
                    $ff = str_replace("اسم_العميل", $client_name, $ff);
                    $ff = str_replace("رقم_العميل", $client_phone, $ff);
                    $ff = str_replace("عدد_الايام", $days, $ff);
                    $ff = str_replace("عدد_الساعات", $hours, $ff);

                    $hdr = " تذكير من الصيدلية ";
                    $body = $hdr . "  " . $ff;

                    echo "Success";
                    sendWhatsappMessage($client_phone, $body);
                    echo "<br>";
                    echo "Current Date: " . date("Y-m-d H:i:s", $currentDate);
                    echo "<br>";
                    echo "Next Start Date: " . $next;
                } else {
                    echo "Error: " . mysqli_error($con);
                }
            } else {
                echo "No action needed";
                echo "<br>";
                echo "Current Date: " . date("Y-m-d H:i:s", $currentDate);
                echo "<br>";
                echo "Next Date: " . date("Y-m-d H:i:s", $nexttime);
                echo "<br>";
            }
        }
    }
    echo '<meta http-equiv="refresh" content="5">'; // Auto-refresh every 5 seconds
} else {
    echo "Error: " . mysqli_error($con);
}

// Close the database connection
mysqli_close($con);
?>
